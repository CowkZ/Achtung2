﻿using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types")]
[assembly: SuppressMessage("Performance", "CA1810:Initialize reference type static fields inline")]
[assembly: SuppressMessage("Style", "IDE0270:Use coalesce expression")]
